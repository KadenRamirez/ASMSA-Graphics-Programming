import numpy as np
import cv2

def show(img,wait=0,destroy=True):
	if img.min()<0 or img.max()>255:
		img=normalize(img)
	img=np.uint8(img)
	cv2.imshow("image",img)
	cv2.waitKey(wait)
	if destroy:
		cv2.destroyAllWindows()

def normalize(img):
	out=img*1.0
	out-=out.min()
	out/=out.max()
	out*=255.99
	return np.uint8(out)

def sharpen(img,w,h,i):
	kernel=np.ones((w,h),dtype=np.float64)
	s=kernel.sum()
	kernel=-kernel
	kernel[int(w/2),int(h/2)]=s            
	print(kernel)
	out=cv2.filter2D(img,-1,kernel)
	if i!=0:
		cv2.imwrite("Output/pic_3_2_" +str(i)+".png",np.uint8(out))
	show(out)
	return(out)

img=cv2.imread("input/image1.png",0)
show(img)
cv2.imwrite("input/imageGS.png",np.uint8(img))

#box Blurs
kernel=np.ones((3,3),dtype=np.float64)/9
out=cv2.filter2D(img,cv2.CV_64F,kernel)
show(out)
print(kernel)
print()
cv2.imwrite("Output/pic_1_2_1.png",np.uint8(out))
kernel=np.ones((7,7),dtype=np.float64)/49
out=cv2.filter2D(img,cv2.CV_64F,kernel)
show(out)
print(kernel)
print()
cv2.imwrite("Output/pic_1_2_2.png",np.uint8(out))
kernel=np.ones((1,7),dtype=np.float64)/7
out=cv2.filter2D(img,cv2.CV_64F,kernel)
show(out)
print(kernel)
print()
cv2.imwrite("Output/pic_1_2_3.png",np.uint8(out))
kernel=np.ones((1,3),dtype=np.float64)/3
out=cv2.filter2D(img,cv2.CV_64F,kernel)
show(out)
print(kernel)
print()
cv2.imwrite("Output/pic_1_2_4.png",np.uint8(out))

#box blur border stuffs
kernel=np.ones((7,7),dtype=np.float64)/49
out=cv2.filter2D(img,cv2.CV_64F,kernel,borderType=cv2.BORDER_CONSTANT)
show(out)
cv2.imwrite("Output/pic_1_3_1.png",np.uint8(out))
out=cv2.filter2D(img,cv2.CV_64F,kernel,borderType=cv2.BORDER_REFLECT)
show(out)
cv2.imwrite("Output/pic_1_3_2.png",np.uint8(out))
out=cv2.filter2D(img,cv2.CV_64F,kernel,borderType=cv2.BORDER_REPLICATE)
show(out)
cv2.imwrite("Output/pic_1_3_3.png",np.uint8(out))

#box blur 7x7 compared to 1x7@7x1
k1=np.ones((7,7),dtype=np.float64)/49
out1=cv2.filter2D(img,cv2.CV_64F,k1)
k2=np.ones((1,7),dtype=np.float64)/7
out2=cv2.filter2D(img,cv2.CV_64F,k1)
k3=k1.T
print(k2)
print()
print(k3)
out2=cv2.filter2D(out2,cv2.CV_64F,k2)
diff= normalize(out1-out2)
show(diff)
print(diff.min(),diff.max())
cv2.imwrite("Output/pic_1_4.png",np.uint8(diff))

#Gaussain Blur
out=cv2.GaussianBlur(img,(3,3),-1)
show(out)
cv2.imwrite("Output/pic_2_2_1.png",np.uint8(out))
out=cv2.GaussianBlur(img,(7,7),-1)
show(out)
cv2.imwrite("Output/pic_2_2_2.png",np.uint8(out))
out=cv2.GaussianBlur(img,(1,7),-1)
show(out)
cv2.imwrite("Output/pic_2_2_3.png",np.uint8(out))
out=cv2.GaussianBlur(img,(1,3),-1)
show(out)
cv2.imwrite("Output/pic_2_2_4.png",np.uint8(out))

#Gaussian border stuffs
out=cv2.GaussianBlur(img,(7,7),-1, borderType=cv2.BORDER_CONSTANT)
show(out)
cv2.imwrite("Output/pic_2_3_1.png",np.uint8(out))
out=cv2.GaussianBlur(img,(7,7),-1, borderType=cv2.BORDER_REFLECT)
show(out)
cv2.imwrite("Output/pic_2_3_2.png",np.uint8(out))
out=cv2.GaussianBlur(img,(7,7),-1, borderType=cv2.BORDER_REPLICATE)
show(out)
cv2.imwrite("Output/pic_2_3_3.png",np.uint8(out))


#Gaussian Blur 7X7 ocmpare to 1x7@7x1
out1=cv2.GaussianBlur(img,(7,7),-1)
show(out1)
k1=cv2.getGaussianKernel(7,7)
k2=k1.T
out2=cv2.filter2D(img,cv2.CV_64F,k1)
out2=cv2.filter2D(out2,cv2.CV_64F,k2)
show(out2)
diff=normalize(out1-out2)
show(diff)
print(diff.min(),diff.max())
cv2.imwrite("Output/pic_2_4.png",np.uint8(diff))

#Sharpen function at top
sharpen(img,3,3,1)
sharpen(img,5,5,2)
sharpen(img,7,7,3)
sharpen(img,9,9,4)

out=sharpen(img,3,3,0)
out=sharpen(out,3,3,5)
out=sharpen(out,3,3,6)

#edge kernel
k1=np.float64([[1,0,-1],[2,0,-2],[1,0,-1]])
out1=cv2.filter2D(img,cv2.CV_64F,k1)
show(out1)
cv2.imwrite("Output/pic_4_1.png",out1)
k2=np.float64([[2,2,0],[2,0,-2],[0,-2,-2]])
out2=cv2.filter2D(img,cv2.CV_64F,k2)
show(out2)
cv2.imwrite("Output/pic_4_2.png",out2)



