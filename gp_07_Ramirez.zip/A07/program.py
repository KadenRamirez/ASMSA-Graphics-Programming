import numpy as np
import cv2
import time
import math

DEBUG=True
"""
basic proccess
take votse
find max
add to list
repeat
"""
#blurring can be a fix so blur the concentration points/votes image.
#min max location function will be usefull.
"""
edges=cv2.Canny(img,10,50)

patch=edges
patch=cv2.rotate(patch,cv2.ROTATE_180)
"""

def show(img,title="image",wait=True):
	d=max(img.shape[:2])
	if d>1000:
		step=int(math.ceil(d/1000))
		img=img[::step,::step]
	if not DEBUG:
		return
	if np.all(0<=img) and np.all(img<256):
		cv2.imshow(title,np.uint8(img))
	else:
		print("normalized version")
		cv2.imshow(title,normalize(img))
	if wait:
		cv2.waitKey(0)
		cv2.destroyAllWindows()
	else:
		cv2.waitKey(100)

def normalize(img):
	img_copy=img*1.0
	img_copy-=np.min(img_copy)
	img_copy/=np.max(img_copy)
	img_copy*=255.9999
	return np.uint8(img_copy)

r=115
img=cv2.imread("input/rl.png",0)[::3,::3]
show(img)
# ~ r//=3
h,w,*_=img.shape
Y,X,R=np.mgrid[:2*r,:2*r,:r]

edges=cv2.Canny(img,10,50)
patch=edges
patch=cv2.rotate(patch,cv2.ROTATE_180)
cv2.imwrite("output/patch.png", np.uint8(patch))

patch=patch[32:262,27:257,None]
show(patch)
print(patch.shape)
print(str(patch) +" this is patch")
# ~ cv2.imwrite("patch.png", np.uint8(patch))

# ~ cone=1-(R-np.hypot(X-r,Y-r))**2
# ~ cone[cone<0]=0
# ~ print(cone.shape)

votes=np.zeros((h+2*r,w+2*r,r),dtype=np.float64)
print(str(votes) + " this is votes")

# ~ kernel=np.float64([[0,0,0],[1,0,-1],[0,0,0]])
# ~ Ix=cv2.filter2D(img,cv2.CV_64F,kernel.T)
# ~ Iy=cv2.filter2D(img,cv2.CV_64F,kernel)
# ~ I=np.sqrt(Ix*Ix+Iy*Iy)
# ~ I/=I.max()
I= cv2.Canny(img,10,50)
show(I)
y,x=np.where(I>128)

for i,j in zip(x,y):
	print(i,j)
	votes[j:j+2*r,i:i+2*r]+=patch
i=0

votes[:,:,:10]=0
R=np.mgrid[:r]
R=R[None,None,:]
print(R.shape)
votes[:,:,10:]/=R[:,:,10:]

maxValue=votes.max()
y,x,z=np.where(votes>maxValue*.75)
img=cv2.imread("input/rl.png")
img=np.float32(img)
show(img)

for i,j,k in zip(x,y,z):
	i=int((i-r)*3)
	j=int((j-r)*3)
	k=int((k)*3)
	cv2.circle(img,(i+10,j),r*3+20,(0,255,0),5)

show(img)
cv2.imwrite("output/highlight.png",np.uint8(img))
show(normalize(votes[:,:,50%r]))
cv2.imwrite("output/votes.png",np.uint8(normalize(votes[:,:,50%r])))
# ~ while 1:
	# ~ show(normalize(votes[:,:,i%r]),wait=0)
	# ~ i+=1

